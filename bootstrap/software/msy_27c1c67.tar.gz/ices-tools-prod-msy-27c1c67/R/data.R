#' @name icesStocks
#' @title icesStocks
#' @description A list FLStock object for various stocks
#' @docType data
#' @usage none
#' @format a list
#' @source NA
#' @author NA
NULL
